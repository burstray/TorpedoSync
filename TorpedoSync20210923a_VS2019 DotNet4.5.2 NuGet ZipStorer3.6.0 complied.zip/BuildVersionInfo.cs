
// build number = 680
// build version = 1.7.6

[assembly: System.Reflection.AssemblyFileVersion("1.7.6.680")]
[assembly: System.Reflection.AssemblyVersion("1.7.5.0")]