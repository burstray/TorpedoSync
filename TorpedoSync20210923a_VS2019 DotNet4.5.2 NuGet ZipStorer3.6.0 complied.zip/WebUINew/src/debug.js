import "./main.js";
window.ServerURL = "http://localhost:88/";
// console.log("debug data server : " + window.ServerURL);
