import {
    faFolderOpen,
    faExchangeAlt,
    faCog,
    faList,
    faQuestionCircle,
    faSortAlphaDown,
    faSortAlphaDownAlt,
    faEdit,
    faSave,
    faFilter,
    faTimes,
    faPlus,
    faPlay,
    faPause
} from "@fortawesome/free-solid-svg-icons";

export default {
    faFolderOpen,
    faExchangeAlt,
    faCog,
    faList,
    faQuestionCircle,
    faSortAlphaDown,
    faSortAlphaDownAlt,
    faEdit,
    faSave,
    faFilter,
    faTimes,
    faPlus,
    faPlay,
    faPause
};